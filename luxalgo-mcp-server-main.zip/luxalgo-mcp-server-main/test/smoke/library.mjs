/* Library tools against the live app API. */

export async function run({ client, check, callJson, httpUrl }) {
  // library_list_families
  const families = await callJson(client, "library_list_families", {});
  check(
    "library_list_families returns 17 families with counts",
    !families.isError &&
      families.payload.families?.length === 17 &&
      families.payload.families.every((f) => f.concept_count > 0),
    `total concepts: ${families.payload.families?.reduce((s, f) => s + f.concept_count, 0)}`,
  );

  // library_list_concepts (filtered)
  const concepts = await callJson(client, "library_list_concepts", {
    family: "momentum",
    page_size: 5,
  });
  check(
    "library_list_concepts (momentum, 5/page) paginates",
    !concepts.isError &&
      concepts.payload.concepts?.length === 5 &&
      concepts.payload.total > 5 &&
      concepts.payload.concepts.every((c) => c.family === "momentum" && c.url),
    `total=${concepts.payload.total}, first=${concepts.payload.concepts?.[0]?.slug}`,
  );

  // library_search — alias-aware
  const search = await callJson(client, "library_search", { query: "stochastics" });
  const conceptHit = search.payload.results?.find((r) => r.kind === "concept");
  check(
    "library_search('stochastics') finds concept via alias",
    !search.isError && !!conceptHit,
    conceptHit ? `${conceptHit.slug}${conceptHit.matched_alias ? ` (alias: ${conceptHit.matched_alias})` : ""}` : "no concept hit",
  );

  // library_search — indicators
  const searchInd = await callJson(client, "library_search", {
    query: "trend",
    type: "indicators",
    limit: 3,
  });
  check(
    "library_search(type=indicators) returns indicator hits",
    !searchInd.isError &&
      searchInd.payload.results?.length > 0 &&
      searchInd.payload.results.every((r) => r.kind === "indicator" && r.url),
    `${searchInd.payload.results?.length} hits, first=${searchInd.payload.results?.[0]?.slug}`,
  );

  // library_get_concept — real slug from the roster
  const conceptSlug = conceptHit?.slug ?? concepts.payload.concepts[0].slug;
  const concept = await callJson(client, "library_get_concept", { slug: conceptSlug });
  check(
    `library_get_concept('${conceptSlug}') returns markdown`,
    !concept.isError &&
      typeof concept.payload.content_markdown === "string" &&
      concept.payload.content_markdown.length > 200,
    `${concept.payload.content_markdown?.length} chars, family=${concept.payload.family}`,
  );

  // library_get_concept — unknown slug -> error + suggestions
  const badConcept = await callJson(client, "library_get_concept", { slug: "stochastic" });
  check(
    "library_get_concept(bad slug) errors with suggestions",
    badConcept.isError && /did you mean/i.test(badConcept.payload.error ?? ""),
    badConcept.payload.error,
  );

  // library_list_indicators
  const indicators = await callJson(client, "library_list_indicators", { page_size: 3 });
  check(
    "library_list_indicators paginates with explicit sort",
    !indicators.isError && indicators.payload.indicators?.length === 3 && indicators.payload.total > 3,
    `total=${indicators.payload.total}, first=${indicators.payload.indicators?.[0]?.slug}`,
  );

  // library_get_indicator + source code on a real slug
  const indSlug = indicators.payload.indicators[0].slug;
  const indicator = await callJson(client, "library_get_indicator", { slug: indSlug });
  check(
    `library_get_indicator('${indSlug}') returns detail + code availability`,
    !indicator.isError &&
      typeof indicator.payload.body_markdown === "string" &&
      typeof indicator.payload.code?.available === "boolean",
    `code.available=${indicator.payload.code?.available}${indicator.payload.code?.reason ? `, reason=${indicator.payload.code.reason}` : ""}`,
  );

  const source = await callJson(client, "library_get_source_code", { slug: indSlug });
  check(
    `library_get_source_code('${indSlug}') matches availability contract`,
    !source.isError &&
      (source.payload.available
        ? typeof source.payload.source === "string" && source.payload.source.length > 0
        : source.payload.reason === "runs-in-quant"),
    source.payload.available
      ? `${source.payload.source?.length} chars of source`
      : `reason=${source.payload.reason}, quant_url=${!!source.payload.quant_url}`,
  );

  // library_get_indicator — unknown slug
  const badInd = await callJson(client, "library_get_indicator", { slug: "not-a-real-indicator-xyz" });
  check("library_get_indicator(bad slug) returns isError", badInd.isError, badInd.payload.error);

  // library_get_family
  const family = await callJson(client, "library_get_family", { key: "smc-ict" });
  check(
    "library_get_family('smc-ict') returns markdown + roster",
    !family.isError &&
      typeof family.payload.content_markdown === "string" &&
      family.payload.concepts?.length > 0,
    `${family.payload.content_markdown?.length} chars, ${family.payload.concepts?.length} concepts`,
  );

  // library_list_tags + tag/concept filters on library_list_indicators
  const tags = await callJson(client, "library_list_tags", {});
  check(
    "library_list_tags returns the tag vocabulary",
    !tags.isError && tags.payload.tags?.length > 0 && tags.payload.tags.every((t) => t.id && t.name),
    `${tags.payload.tags?.length} tags, first=${tags.payload.tags?.[0]?.name}`,
  );

  const byConcept = await callJson(client, "library_list_indicators", {
    concept: "rsi",
    page_size: 3,
  });
  check(
    "library_list_indicators(concept='rsi') filters server-side",
    !byConcept.isError && byConcept.payload.total > 0 && byConcept.payload.indicators.length > 0,
    `total=${byConcept.payload.total}, first=${byConcept.payload.indicators?.[0]?.slug}`,
  );
}
